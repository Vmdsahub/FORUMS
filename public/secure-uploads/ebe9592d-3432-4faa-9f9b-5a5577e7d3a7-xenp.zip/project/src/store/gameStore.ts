import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { GameState, User, Pet, Item, Notification, Achievement, Collectible, Quest } from '../types/game';
import { gameService } from '../services/gameService';

// Sistema Universal de Itens - Base de dados central com imagens
const UNIVERSAL_ITEMS: Record<string, Item> = {
  'health-potion-1': {
    id: 'health-potion-1',
    name: 'Health Potion',
    description: 'A magical elixir that restores 5 health points instantly',
    type: 'Potion',
    rarity: 'Common',
    price: 50,
    currency: 'xenocoins',
    effects: { health: 5 },
    quantity: 1,
    imageUrl: 'https://images.pexels.com/photos/3735747/pexels-photo-3735747.jpeg?auto=compress&cs=tinysrgb&w=200',
    createdAt: new Date()
  },
  'magic-apple-1': {
    id: 'magic-apple-1',
    name: 'Magic Apple',
    description: 'A mystical fruit that restores hunger and provides energy. Hunger decays over time, so feed your pet regularly!',
    type: 'Food',
    rarity: 'Uncommon',
    price: 25,
    currency: 'xenocoins',
    effects: { hunger: 3, happiness: 1 },
    quantity: 1,
    imageUrl: 'https://images.pexels.com/photos/102104/pexels-photo-102104.jpeg?auto=compress&cs=tinysrgb&w=200',
    createdAt: new Date()
  },
  'happiness-toy-1': {
    id: 'happiness-toy-1',
    name: 'Happiness Toy',
    description: 'A colorful toy that brings joy to pets',
    type: 'Special',
    rarity: 'Common',
    price: 30,
    currency: 'xenocoins',
    effects: { happiness: 2 },
    quantity: 1,
    imageUrl: 'https://images.pexels.com/photos/1619690/pexels-photo-1619690.jpeg?auto=compress&cs=tinysrgb&w=200',
    createdAt: new Date()
  },
  'energy-drink-1': {
    id: 'energy-drink-1',
    name: 'Energy Drink',
    description: 'A refreshing beverage that boosts pet stats temporarily',
    type: 'Potion',
    rarity: 'Uncommon',
    price: 75,
    currency: 'xenocoins',
    effects: { speed: 2, dexterity: 1 },
    quantity: 1,
    imageUrl: 'https://images.pexels.com/photos/2775860/pexels-photo-2775860.jpeg?auto=compress&cs=tinysrgb&w=200',
    createdAt: new Date()
  },
  'desert-crystal-1': {
    id: 'desert-crystal-1',
    name: 'Desert Crystal',
    description: 'A rare crystal that enhances pet intelligence permanently',
    type: 'Special',
    rarity: 'Rare',
    price: 200,
    currency: 'xenocoins',
    effects: { intelligence: 3 },
    quantity: 1,
    imageUrl: 'https://images.pexels.com/photos/1121123/pexels-photo-1121123.jpeg?auto=compress&cs=tinysrgb&w=200',
    createdAt: new Date()
  },
  'iron-armor-1': {
    id: 'iron-armor-1',
    name: 'Iron Armor',
    description: 'Sturdy armor that provides excellent protection',
    type: 'Equipment',
    rarity: 'Rare',
    price: 500,
    currency: 'xenocoins',
    effects: { defense: 5, health: 2 },
    slot: 'torso',
    quantity: 1,
    imageUrl: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg?auto=compress&cs=tinysrgb&w=200',
    createdAt: new Date()
  },
  'crystal-sword-1': {
    id: 'crystal-sword-1',
    name: 'Crystal Sword',
    description: 'A powerful weapon forged from mountain crystals',
    type: 'Weapon',
    rarity: 'Epic',
    price: 1000,
    currency: 'xenocoins',
    effects: { attack: 8, strength: 3 },
    quantity: 1,
    imageUrl: 'https://images.pexels.com/photos/1670977/pexels-photo-1670977.jpeg?auto=compress&cs=tinysrgb&w=200',
    createdAt: new Date()
  },
  'premium-elixir-1': {
    id: 'premium-elixir-1',
    name: 'Premium Elixir',
    description: 'An expensive but powerful healing potion that fully restores health and happiness',
    type: 'Potion',
    rarity: 'Epic',
    price: 5,
    currency: 'cash',
    effects: { health: 10, happiness: 3 },
    quantity: 1,
    imageUrl: 'https://images.pexels.com/photos/3735747/pexels-photo-3735747.jpeg?auto=compress&cs=tinysrgb&w=200',
    createdAt: new Date()
  },
  'super-food-1': {
    id: 'super-food-1',
    name: 'Super Food',
    description: 'Premium pet food that completely satisfies hunger and boosts happiness',
    type: 'Food',
    rarity: 'Rare',
    price: 100,
    currency: 'xenocoins',
    effects: { hunger: 5, happiness: 2, health: 1 },
    quantity: 1,
    imageUrl: 'https://images.pexels.com/photos/1059905/pexels-photo-1059905.jpeg?auto=compress&cs=tinysrgb&w=200',
    createdAt: new Date()
  },
  'strength-potion-1': {
    id: 'strength-potion-1',
    name: 'Strength Potion',
    description: 'A powerful brew that permanently increases your pet\'s strength',
    type: 'Potion',
    rarity: 'Rare',
    price: 150,
    currency: 'xenocoins',
    effects: { strength: 2, attack: 1 },
    quantity: 1,
    imageUrl: 'https://images.pexels.com/photos/2775860/pexels-photo-2775860.jpeg?auto=compress&cs=tinysrgb&w=200',
    createdAt: new Date()
  }
};

interface GameStore extends GameState {
  // Actions
  setUser: (user: User | null) => void;
  setActivePet: (pet: Pet | null) => void;
  addNotification: (notification: Omit<Notification, 'id' | 'createdAt'>) => void;
  markNotificationAsRead: (id: string) => void;
  clearNotifications: () => void;
  updateCurrency: (type: 'xenocoins' | 'cash', amount: number) => void;
  setCurrentScreen: (screen: string) => void;
  setLanguage: (language: string) => void;
  addToInventory: (item: Item) => void;
  removeFromInventory: (itemId: string, quantity?: number) => void;
  useItem: (itemId: string, petId: string) => void;
  equipItem: (itemId: string, petId: string) => void;
  unequipItem: (slot: string, petId: string) => void;
  updatePetStats: (petId: string, stats: Partial<Pet>) => void;
  addAchievement: (achievement: Achievement) => void;
  updateQuestProgress: (questId: string, progress: Record<string, number>) => void;
  completeQuest: (questId: string) => void;
  resetProgress: () => void;
  initializeNewUser: (user: User) => void;
  loadUserData: (userId: string) => Promise<void>;
  syncWithDatabase: () => Promise<void>;
  searchPlayers: (query: string) => Promise<User[]>;
  getPlayerProfile: (userId: string) => Promise<User | null>;
  createPet: (petData: Omit<Pet, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Pet | null>;
  
  // Universal Item System
  getUniversalItem: (itemId: string) => Item | null;
  getAllUniversalItems: () => Item[];
  addUniversalItem: (item: Item) => void;
  updateUniversalItem: (itemId: string, updates: Partial<Item>) => void;
  deleteUniversalItem: (itemId: string) => void;
}

// Helper function to convert date strings back to Date objects
const rehydrateDates = (obj: any): any => {
  if (!obj) return obj;
  
  if (typeof obj === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/.test(obj)) {
    return new Date(obj);
  }
  
  if (Array.isArray(obj)) {
    return obj.map(rehydrateDates);
  }
  
  if (typeof obj === 'object') {
    const result: any = {};
    for (const [key, value] of Object.entries(obj)) {
      if (key === 'createdAt' || key === 'updatedAt' || key === 'lastInteraction' || 
          key === 'hatchTime' || key === 'deathDate' || key === 'lastLogin' ||
          key === 'completedAt' || key === 'startedAt' || key === 'unlockedAt' ||
          key === 'collectedAt' || key === 'acquiredAt' || key === 'lastUsed') {
        result[key] = typeof value === 'string' ? new Date(value) : value;
      } else {
        result[key] = rehydrateDates(value);
      }
    }
    return result;
  }
  
  return obj;
};

const createInitialGameState = (): Omit<GameState, 'user'> => ({
  activePet: null,
  pets: [],
  inventory: [],
  xenocoins: 1000,
  cash: 10,
  notifications: [],
  language: 'pt-BR',
  currentScreen: 'pet',
  achievements: [],
  collectibles: [],
  quests: []
});

export const useGameStore = create<GameStore>()(
  persist(
    (set, get) => ({
      ...createInitialGameState(),
      user: null,

      setUser: (user) => set({ user }),
      setActivePet: (activePet) => set({ activePet }),
      
      addNotification: async (notification) => {
        const state = get();
        if (state.user) {
          // Add to database
          await gameService.addNotification(state.user.id, notification);
          
          // Add to local state
          set((state) => ({
            notifications: [{
              ...notification,
              id: Date.now().toString(),
              createdAt: new Date()
            }, ...state.notifications.slice(0, 49)]
          }));
        }
      },
      
      markNotificationAsRead: async (id) => {
        await gameService.markNotificationAsRead(id);
        set((state) => ({
          notifications: state.notifications.map(n => 
            n.id === id ? { ...n, isRead: true } : n
          )
        }));
      },

      clearNotifications: () => set((state) => ({
        notifications: state.notifications.filter(n => !n.isRead)
      })),
      
      updateCurrency: async (type, amount) => {
        const state = get();
        if (!state.user) return;

        // Update in database
        const success = await gameService.updateUserCurrency(state.user.id, type, amount);
        
        if (success) {
          set((state) => {
            const newAmount = Math.max(0, state[type] + amount);
            
            // Add notification for significant currency changes
            if (Math.abs(amount) >= 100) {
              const notification = {
                type: amount > 0 ? 'success' : 'warning' as const,
                title: amount > 0 ? 'Moedas Ganhas' : 'Moedas Gastas',
                message: `${amount > 0 ? '+' : ''}${amount} ${type === 'xenocoins' ? 'Xenocoins' : 'Cash'}`,
                isRead: false
              };
              
              return {
                [type]: newAmount,
                notifications: [{
                  ...notification,
                  id: Date.now().toString(),
                  createdAt: new Date()
                }, ...state.notifications]
              };
            }
            
            return { [type]: newAmount };
          });
        }
      },
      
      setCurrentScreen: (currentScreen) => set({ currentScreen }),
      setLanguage: (language) => set({ language }),
      
      addToInventory: async (item) => {
        const state = get();
        if (!state.user) return;

        // Get the universal item to ensure we have the complete data
        const universalItem = get().getUniversalItem(item.id);
        const itemToAdd = universalItem || item;

        // Add to database
        await gameService.addItemToInventory(state.user.id, itemToAdd.id, itemToAdd.quantity);
        
        // Add to local state
        set((state) => {
          const existingItem = state.inventory.find(i => i.id === itemToAdd.id);
          if (existingItem) {
            return {
              inventory: state.inventory.map(i => 
                i.id === itemToAdd.id ? { ...i, quantity: i.quantity + itemToAdd.quantity } : i
              )
            };
          }
          return { inventory: [...state.inventory, itemToAdd] };
        });
      },
      
      removeFromInventory: (itemId, quantity = 1) => set((state) => ({
        inventory: state.inventory.reduce((acc, item) => {
          if (item.id === itemId) {
            const newQuantity = item.quantity - quantity;
            if (newQuantity > 0) {
              acc.push({ ...item, quantity: newQuantity });
            }
          } else {
            acc.push(item);
          }
          return acc;
        }, [] as Item[])
      })),
      
      useItem: (itemId, petId) => {
        const state = get();
        const item = state.inventory.find(i => i.id === itemId) || get().getUniversalItem(itemId);
        const pet = state.pets.find(p => p.id === petId);
        
        if (!item || !pet) return;
        
        // Apply item effects to pet
        if (item.effects) {
          const updatedStats: Partial<Pet> = {};
          Object.entries(item.effects).forEach(([stat, value]) => {
            if (stat in pet) {
              const currentValue = pet[stat as keyof Pet] as number;
              const maxValue = ['health', 'happiness', 'hunger'].includes(stat) ? 10 : currentValue + value;
              updatedStats[stat as keyof Pet] = Math.min(maxValue, Math.max(0, currentValue + value));
            }
          });
          
          get().updatePetStats(petId, updatedStats);
        }
        
        // Remove item from inventory
        get().removeFromInventory(itemId, 1);
        
        // Add notification with item effects
        const effectsText = item.effects ? 
          Object.entries(item.effects).map(([stat, value]) => `+${value} ${stat}`).join(', ') : 
          'efeitos aplicados';
        
        get().addNotification({
          type: 'success',
          title: 'Item Usado',
          message: `${item.name} foi usado em ${pet.name}! ${effectsText}`
        });
      },
      
      equipItem: (itemId, petId) => {
        console.log(`Equipping item ${itemId} on pet ${petId}`);
      },
      
      unequipItem: (slot, petId) => {
        console.log(`Unequipping ${slot} from pet ${petId}`);
      },
      
      updatePetStats: async (petId, stats) => {
        const state = get();
        if (!state.user) return;

        // Update in database
        await gameService.updatePetStats(petId, stats);
        
        // Update local state
        set((state) => ({
          pets: state.pets.map(pet => 
            pet.id === petId ? { ...pet, ...stats, updatedAt: new Date() } : pet
          ),
          activePet: state.activePet?.id === petId ? { ...state.activePet, ...stats, updatedAt: new Date() } : state.activePet
        }));
      },
      
      addAchievement: (achievement) => set((state) => ({
        achievements: [...state.achievements, achievement]
      })),
      
      updateQuestProgress: (questId, progress) => set((state) => ({
        quests: state.quests.map(quest => 
          quest.id === questId ? { ...quest, progress: { ...quest.progress, ...progress } } : quest
        )
      })),
      
      completeQuest: (questId) => set((state) => ({
        quests: state.quests.map(quest => 
          quest.id === questId ? { ...quest, isCompleted: true, completedAt: new Date() } : quest
        )
      })),

      resetProgress: () => {
        const initialState = createInitialGameState();
        set({
          ...initialState,
          user: get().user
        });
      },

      initializeNewUser: (user) => {
        const initialState = createInitialGameState();
        set({
          ...initialState,
          user,
          language: user.language
        });
      },

      loadUserData: async (userId: string) => {
        try {
          // Load user pets
          const pets = await gameService.getUserPets(userId);
          
          // Load user inventory
          const inventory = await gameService.getUserInventory(userId);
          
          // Load user notifications
          const notifications = await gameService.getUserNotifications(userId);
          
          // Load user currency
          const currency = await gameService.getUserCurrency(userId);
          
          set({
            pets,
            inventory,
            notifications,
            xenocoins: currency?.xenocoins || 1000,
            cash: currency?.cash || 10,
            activePet: pets.length > 0 ? pets[0] : null
          });
        } catch (error) {
          console.error('Error loading user data:', error);
        }
      },

      syncWithDatabase: async () => {
        const state = get();
        if (state.user) {
          await get().loadUserData(state.user.id);
        }
      },

      searchPlayers: async (query: string) => {
        try {
          return await gameService.searchPlayers(query);
        } catch (error) {
          console.error('Error searching players:', error);
          return [];
        }
      },

      getPlayerProfile: async (userId: string) => {
        try {
          return await gameService.getPlayerProfile(userId);
        } catch (error) {
          console.error('Error fetching player profile:', error);
          return null;
        }
      },

      createPet: async (petData) => {
        const state = get();
        if (!state.user) return null;

        try {
          const newPet = await gameService.createPet({
            ...petData,
            ownerId: state.user.id
          });

          if (newPet) {
            set((state) => ({
              pets: [...state.pets, newPet],
              activePet: state.pets.length === 0 ? newPet : state.activePet
            }));
          }

          return newPet;
        } catch (error) {
          console.error('Error creating pet:', error);
          return null;
        }
      },

      // Universal Item System Methods
      getUniversalItem: (itemId: string) => {
        return UNIVERSAL_ITEMS[itemId] || null;
      },

      getAllUniversalItems: () => {
        return Object.values(UNIVERSAL_ITEMS);
      },

      addUniversalItem: (item: Item) => {
        UNIVERSAL_ITEMS[item.id] = { ...item };
        
        // Add notification for admin
        get().addNotification({
          type: 'success',
          title: 'Item Universal Criado',
          message: `${item.name} foi adicionado ao sistema universal de itens!`
        });
      },

      updateUniversalItem: (itemId: string, updates: Partial<Item>) => {
        if (UNIVERSAL_ITEMS[itemId]) {
          UNIVERSAL_ITEMS[itemId] = { ...UNIVERSAL_ITEMS[itemId], ...updates };
          
          // Update all instances in inventories
          set((state) => ({
            inventory: state.inventory.map(item => 
              item.id === itemId ? { ...item, ...updates } : item
            )
          }));
          
          get().addNotification({
            type: 'info',
            title: 'Item Universal Atualizado',
            message: `${UNIVERSAL_ITEMS[itemId].name} foi atualizado no sistema!`
          });
        }
      },

      deleteUniversalItem: (itemId: string) => {
        if (UNIVERSAL_ITEMS[itemId]) {
          const itemName = UNIVERSAL_ITEMS[itemId].name;
          delete UNIVERSAL_ITEMS[itemId];
          
          // Remove from all inventories
          set((state) => ({
            inventory: state.inventory.filter(item => item.id !== itemId)
          }));
          
          get().addNotification({
            type: 'warning',
            title: 'Item Universal Removido',
            message: `${itemName} foi removido do sistema e de todos os inventários!`
          });
        }
      }
    }),
    {
      name: 'xenopets-game-state',
      partialize: (state) => ({
        user: state.user,
        language: state.language,
        currentScreen: state.currentScreen
      }),
      onRehydrateStorage: () => (state) => {
        if (state) {
          // Rehydrate all date fields in the state
          if (state.user) {
            state.user = rehydrateDates(state.user);
          }
        }
      }
    }
  )
);